<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                        </div>
                    </div>
                </footer><?php /**PATH C:\xampp\htdocs\basic\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>